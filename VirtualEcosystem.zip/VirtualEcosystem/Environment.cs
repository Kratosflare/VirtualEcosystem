﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using static System.Console;

namespace VirtualEcosystem
{
    class Environment
    {
        string name = "Tundra";

     public void Layout()
        {

            
            string[,] grid = {{ "|", " ", " ", "0"," "," "," "," "," ", "|" },
                { "|", " ", " ", " "," "," "," "," "," ", "|" },
                { "|", " ", " ", " "," "," "," "," "," ", "|" },
                { "|", " ", " ", " "," "," "," "," "," ", "|" },
                { "|", " ", " ", " "," "," "," "," "," ", "|" },
                { "|", " ", " ", " "," "," "," "," "," ", "|" },
                    { "|", " ", " ", " "," "," "," "," "," ", "|" },
             { "|", " ", " ", " "," "," "," "," "," ", "|" },
              { "|", " ", " ", " "," "," "," "," "," ", "|" },
              { "|", " ", " ", " "," "," "," "," "," ", "|" },
              { "|", " ", " ", " "," "," "," "," "," ", "|" },
             { "|", " ", " ", " "," ","X"," "," "," ", "|" },
             { "|", "_", "_", "_","_","_","_","_","_", "|" },};

            WriteLine(DateTime.Now.DayOfWeek);
            
            SetCursorPosition(0, 0);
            Write("0");
            int row = grid.GetLength(0);
            int column = grid.GetLength(1);
            for (int y = 0;  y<row; y++)
            {
                for (int x = 0; x < column; x++)
                {
                    string element = grid[y, x];
                    SetCursorPosition(x, y);
                    Write(element);
                }
            }


        }
        public void Draw()
        {

        }
    }
}
