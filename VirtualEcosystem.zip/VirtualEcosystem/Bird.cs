﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystem
{
    class Bird: Organism, Predator
    {
        string Name;
        string color;
        public Bird(string n, string c)
        {
            n = Name;
            c = color;


            List<Bird> birds = new List<Bird>();

            birds.Add(new Bird("Raven", "black"));
        }
    }
}
