﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystem
{

        interface ISpecies
     {

        }
    interface Prey
    {

    }
    interface Predator
    {

    }
    
}
