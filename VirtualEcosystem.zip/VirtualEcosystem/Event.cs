﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace VirtualEcosystem
{
    public delegate void Weather();
    class Event
    {
        // public event dsvsfvgwrfw;
        string duration;
        string warning;
        double areaOfEffect;

       // void Weather(string d, )

    }
}
