﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace VirtualEcosystem
{
    class Organism
    {
        Timer timer = new Timer();
        string name;
        string description;
        Dictionary<Prey, Predator> dataBase = new Dictionary<Prey, Predator>();
        public Organism()
        {
            Spawn();
        }
        /// <summary>
        /// Spawn creates the animal and provides a brief biological description of the animal
        /// </summary>
         void Spawn()
        {
            while (timer.Enabled && dataBase.Count != 101)
            {
                dataBase.Add(new Rabbit(), new Bird("Cardinal","red"));
            }

        }
   }
}
