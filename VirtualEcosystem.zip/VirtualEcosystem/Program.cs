﻿using System;
//Intro to C#: 22 - Creating an Explorable Maze by Michael Hadley\
//https://www.youtube.com/watch?v=T0MpWTbwseg&list=PL-LDQE9x9hLwldZPPGwqXixr-_DfINfxk&index=23
/*Time-Based Example

After a set amount of time, the environment and organisms will have methods run (no matter if the player has acted or not). 

2. Player actions can impact the environment
and organisms in positive and negative ways. 
For example, the player can farm materials from plants to make items. 
Many of the items the player can make can improve the environment/organisms.
However, if the player takes too many materials the plants can die.

3. At least two sub-systems are active to some extent (even if they are not both fully implemented). 
Each system should have inputs and outputs, and results should have an impact on other elements in the application. 
(Example: a weather system that provides positives such as sunlight, water, etc. The positives increase growth of plants and organisms.
There is a possibility of adverse weather, however, which can have a range of results (from minor inconvenience to loss of plants and organisms).*/
namespace VirtualEcosystem
{
    class Program
    {
        static void Main()
        {
            Player player = new Player("Barby");
            player.Check();
        }
    }
}
