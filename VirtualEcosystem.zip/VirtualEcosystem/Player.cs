﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using static System.Console;

namespace VirtualEcosystem
{
    public class Player
    {
        private List<Item> backPack = new List<Item>();
        DateTime dt = new DateTime();

        Environment envo = new Environment();

        string playerInput;
      
        public Player (string Name)
        {
           
            backPack.Add(new Item());
            Title = "Tundra";
           
           // WriteLine(dt.TimeOfDay.ToString());
            WriteLine("Hello, Welcome to the " + Title);
            playerInput = ReadLine();
            //Check();
            // WriteLine("Press any key to continue");
            // ReadKey();
            WriteLine("Here, the wildlife has a unstable ecosystem.\nYour job is to plant trees in certain locations using the seeds given to stabilize the environment.");
            WriteLine("The first objective is in location 1. Open your map to get started.");
            WriteLine("1) Open Map  2)Exit");
            playerInput = ReadLine();

            if (playerInput == "1")
            {
                Map();
            }
            else if (playerInput =="2")
            {
                ReadKey(true);
            }
        }
        private void Time(object sender, EventArgs e)
        {
            sender = DateTime.Now.ToLongTimeString();
            // sender.start();
            WriteLine(sender);
        }
        public  void Check()
        {
            foreach (var item in backPack)
            {
                WriteLine($"You have{backPack.Count.ToString()}");
            }
            
        }

        void Map()
        {
            Clear();
            WriteLine("It's blank...... You haven't been anywhere yet! So we'll give you a rudimentary design of your destination.");
            ReadKey(true);
            Clear();
            envo.Layout();
            //  WriteLine(map.Length.ToString());
            if (false)
            {
                
            }
        }
    }
}
