﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystem
{
  interface IKeyItem
    {

    }
    class Item
    {
       public bool available;
        int capacity;
        string description;
        string condition;

        void Use()
        {

        }
       
    }
}
