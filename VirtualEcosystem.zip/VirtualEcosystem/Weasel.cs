﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystem
{
    class Weasel : Organism, Prey
    {
    }
}
